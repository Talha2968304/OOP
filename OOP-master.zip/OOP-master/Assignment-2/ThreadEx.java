package OOP;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ThreadEx{

    public static void main(String[] args) throws InterruptedException{

         for(int i=0; i<5; i++){
             System.out.println(2);
             Thread.sleep(500);
        }
       
    }
}
